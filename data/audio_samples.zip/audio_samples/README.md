# audio_samples.zip

This archive contains synthetic audio samples generated for teaching purposes.

audio/
Contents:
- sine_1k.wav
- chirp_linear.wav
- white_noise.wav

Sample rate: 16 kHz
Mono
Duration: 3 seconds

All files are generated programmatically.
No copyrighted material is included.

synthetic_speech/
Contents:
sample_0.wav
sample_1.wav
sample_2.wav
sample_3.wav
sample_4.wav
sample_5.wav
sample_6.wav
sample_7.wav
sample_8.wav

Sample rate: 16 kHz
Mono
Duration: 4 or 5 seconds

All files are generated programmatically.
No copyrighted material is included.
