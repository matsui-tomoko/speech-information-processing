# audio_samples.zip

This archive contains synthetic audio samples generated for teaching purposes.

Contents:
- sine_1k.wav
- chirp_linear.wav
- white_noise.wav

Sample rate: 16 kHz
Mono
Duration: 3 seconds

All files are generated programmatically.
No copyrighted material is included.
